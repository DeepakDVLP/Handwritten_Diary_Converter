
# Handwritten Diary to Digital Table Converter

This project converts handwritten diary images into digital tables using OCR (Optical Character Recognition).
It is built with Python, Streamlit for the web interface, and EasyOCR for text recognition.

## Folder Structure
- app/: Contains the main Streamlit app code.
- data/: Store training images and test images here.
- model/: For any future model improvements or fine-tuning.
- requirements/: Python dependencies file.

## How to Run
1. Install dependencies from requirements/requirements.txt
2. Run: `streamlit run app/main.py`
3. Access the app in the browser on the given localhost link.

## Hosting
Free hosting can be done on [Streamlit Community Cloud](https://streamlit.io/cloud) by connecting your GitHub repo.
